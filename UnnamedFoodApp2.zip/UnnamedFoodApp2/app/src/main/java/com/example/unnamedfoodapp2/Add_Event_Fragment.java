package com.example.unnamedfoodapp2;

import android.support.v4.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

import static com.example.unnamedfoodapp2.MainActivity.myDB;

public class Add_Event_Fragment extends Fragment {
    private Button addEventBn;
    private EditText eventName, eventAdd, eventDesc, eventStart, eventEnd;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.add_event_page, container, false);

        eventName = v.findViewById(R.id.newEventName);
        eventAdd = v.findViewById(R.id.newEventAddress);
        eventDesc = v.findViewById(R.id.newEventDescription);
        eventStart = v.findViewById(R.id.newEventStart);
        eventEnd = v.findViewById(R.id.newEventEnd);


        //finding the submit button then adding an onclickview to submit into the database.
        addEventBn = v.findViewById(R.id.submitNewEventButton);
        addEventBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                // Sets the eventName, which is the key for the database.
                String newEventName = eventName.getText().toString();

                String newEventAdd = eventAdd.getText().toString();
                String newEventDesc = eventDesc.getText().toString();
                String newEventStart = eventStart.getText().toString();
                String newEventEnd = eventEnd.getText().toString();

                int newEventStart2 = 0;
                int newEventEnd2 = 0;

                if (!(newEventStart.equals("")) && !(newEventEnd.equals(""))) {
                    newEventStart2 = Integer.parseInt(newEventStart);
                    newEventEnd2 = Integer.parseInt(newEventEnd);
                } else
                    eventStart.setError("Please add a start time and end time");

                int currentEventCt = MainActivity.myDB.myDao().getEventCt();

                if (isUsed(newEventName))
                    eventName.setError("This event's name is already in use, " +
                            "please name it something else.");
                else if (newEventName.equals(""))
                    eventName.setError("Please enter an event name");
                else if (newEventAdd.equals(""))
                    eventAdd.setError("Please specify an event address");
                else if (newEventDesc.equals(""))
                    eventDesc.setError("Please enter a description for your event");
                else if ((newEventStart.equals("")) || (newEventEnd.equals("")))
                    eventStart.setError("Please add a start time and end time");
                else {

                    FoodEvent event = new FoodEvent(newEventName, newEventAdd, newEventDesc, newEventStart2,
                            newEventEnd2, false, false, false, false, false, false, false, false);

                    MainActivity.myDB.myDao().addEvent(event);

                    Toast.makeText(getActivity(), "Event added successfully", Toast.LENGTH_LONG).show();

                    eventName.setText("");
                    eventAdd.setText("");
                    eventDesc.setText("");
                    eventStart.setText("");
                    eventEnd.setText("");
                }


            }
        });
        return v;
    }

    public boolean isUsed(String eventName)
    {
        List<FoodEvent> events = myDB.myDao().getEvents();
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).getEventName().equals(eventName))
                return true;
        }
        return false;

    }

}