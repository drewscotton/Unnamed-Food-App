package com.example.unnamedfoodapp2;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Button;

import java.util.List;

public class Event_Page extends Fragment {
    public TextView eventName, eventAdd, eventDesc, eventTime;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.event_page, container, false);
        //FoodEvent currentEvent;
        List<FoodEvent> foodEvents = MainActivity.myDB.myDao().getEvents();
        for (int i = 0; i< foodEvents.size(); i++) {
            if(foodEvents.get(i).isLastUsed()) {
                //currentEvent = event;
                eventName = view.findViewById(R.id.theeventname);
                eventAdd = view.findViewById(R.id.theeventaddress);
                eventDesc = view.findViewById(R.id.theeventdesc);
                eventTime = view.findViewById(R.id.theeventtime);

                eventName.setText(foodEvents.get(i).getEventName());
                eventAdd.setText(foodEvents.get(i).getEventAdd());
                eventDesc.setText(foodEvents.get(i).getEventDesc());
            }

            else {
                ;
            }
        }

        

        return view;
    }

}
