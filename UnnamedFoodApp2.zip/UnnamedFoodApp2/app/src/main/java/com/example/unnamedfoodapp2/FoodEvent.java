package com.example.unnamedfoodapp2;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

//The FoodEvent object class, also creates the table for MyDB.

@Entity(tableName = "foodEvents")
public class FoodEvent {
    @PrimaryKey
    @NonNull
    private String eventName;

    @ColumnInfo
    private String eventAdd;
    @ColumnInfo
    private String eventDesc;
    @ColumnInfo
    private int eventStart;
    @ColumnInfo
    private int eventEnd;
    @ColumnInfo
    private boolean onMon;
    @ColumnInfo
    private boolean onTues;
    @ColumnInfo
    private boolean onWed;
    @ColumnInfo
    private boolean onThurs;
    @ColumnInfo
    private boolean onFri;
    @ColumnInfo
    private boolean onSat;
    @ColumnInfo
    private boolean onSun;
    @ColumnInfo
    private boolean lastUsed;

    @Ignore
    public FoodEvent() {

    }

    public FoodEvent(String eventName, String eventDesc, String eventAdd, int eventStart, int eventEnd,
                     boolean onMon, boolean onTues, boolean onWed, boolean onThurs, boolean onFri, boolean onSat, boolean onSun,
                     boolean lastUsed)
    {
        this.eventName = eventName;
        this.eventDesc = eventDesc;
        this.eventAdd = eventAdd;
        this.eventStart = eventStart;
        this.eventEnd = eventEnd;
        this.onMon = onMon;
        this.onTues = onTues;
        this.onWed = onWed;
        this.onThurs = onThurs;
        this.onFri = onFri;
        this.onSat = onSat;
        this.onSun = onSun;
        this.lastUsed = lastUsed;

    }

    public void setEventName(String eventName)
    {
        this.eventName = eventName;
    }

    public void setEventAdd(String eventAdd)
    {
        this.eventAdd = eventAdd;
    }

    public void setEventDesc(String eventDesc)
    {
        this.eventDesc = eventDesc;
    }

    public void setEventStart(int eventStart)
    {
        this.eventStart = eventStart;
    }

    public void setEventEnd(int eventEnd)
    {
        this.eventEnd = eventEnd;
    }

    public void setOnMon(boolean onMon) {this.onMon = onMon;}
    public void setOnTues(boolean onTues) {this.onTues = onTues;}
    public void setOnWed(boolean onWed) {this.onWed = onWed;}
    public void setOnThurs(boolean onThurs) {this.onThurs = onThurs;}
    public void setOnFri(boolean onFri) {this.onFri = onFri;}
    public void setOnSat(boolean onSat) {this.onSat = onSat;}
    public void setOnSun(boolean onSun) {this.onSun = onSun;}
    public void setLastUsed(boolean lastUsed) {this.lastUsed = lastUsed;}

    public String getEventName()
    {
        return eventName;
    }
    public String getEventAdd()
    {
        return eventAdd;
    }
    public String getEventDesc(){ return eventDesc; }
    public int getEventStart(){ return eventStart; }
    public int getEventEnd(){ return eventEnd; }
    public boolean isOnMon() { return onMon; }
    public boolean isOnTues() { return onTues; }
    public boolean isOnWed() { return onWed; }
    public boolean isOnThurs() { return onThurs; }
    public boolean isOnFri() { return onFri; }
    public boolean isOnSat() { return onSat; }
    public boolean isOnSun() { return onSun; }
    public boolean isLastUsed() {return lastUsed; }





}
