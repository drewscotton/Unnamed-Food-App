package com.example.unnamedfoodapp2;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Button;

import java.util.List;

import static java.lang.String.format;

public class Home_Fragment extends Fragment {
    TextView populateEvents;
    Button eventbutton1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_main, container, false);
        populateEvents = view.findViewById(R.id.testDBPopulate);
        eventbutton1 = view.findViewById(R.id.eventbutton1);



        List<FoodEvent> foodEvents = MainActivity.myDB.myDao().getEvents();
        FoodEvent ev1 = foodEvents.get(0);
        if (!(foodEvents.isEmpty())) {
            //will put a switch here for multiple buttons
            ev1.setLastUsed(true);
            MainActivity.myDB.myDao().updateEvent(ev1);
            eventbutton1.setText(ev1.getEventName());
        }
        String stuff = "";
        for (FoodEvent event : foodEvents) {
            if (event != null) {
                String eventName = event.getEventName();
                String eventAdd = event.getEventAdd();
                String eventDesc = event.getEventDesc();
                int eventStart = event.getEventStart();
                int eventEnd = event.getEventEnd();

                stuff += eventName + "     " + eventAdd + "     " + eventDesc + "     " + eventStart + "     " + eventEnd + "    " +
                        event.isLastUsed() + "\n";


            } else
                break;
        }
        populateEvents.setText(stuff);

        String buttontext = eventbutton1.getText().toString();
        if(!(buttontext.equals("No Events"))) {

            eventbutton1.setOnClickListener(new View.OnClickListener() {

                                                @Override
                                                public void onClick(View v) {
                                                    getFragmentManager().beginTransaction().replace(R.id.fragment_container,
                                                            new Event_Page()).commit();

                                                }
                                            }
            );

        }
        return view;
    }

}
