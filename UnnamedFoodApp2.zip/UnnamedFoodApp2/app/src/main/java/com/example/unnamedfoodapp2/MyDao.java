package com.example.unnamedfoodapp2;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
interface MyDao {
    @Insert
    void addEvent(FoodEvent i);

    @Query("select * from foodevents")
    List<FoodEvent> getEvents();

    @Query("select * from foodevents where eventName = :eventName")
    FoodEvent loadEventByName(String eventName);

    @Update
    void updateEvent(FoodEvent i);

    @Delete
    void deleteEvent(FoodEvent i);

    @Query("DELETE FROM foodevents where eventName = :eventName")
    void deleteByEventName(String eventName);

    @Query("SELECT COUNT(eventName) FROM foodevents")
    int getEventCt();

}